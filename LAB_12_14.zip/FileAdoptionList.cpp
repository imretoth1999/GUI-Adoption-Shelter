#include "FileAdoption.h"

FileAdoptionList::FileAdoptionList() :AdoptionList{}
{
}

